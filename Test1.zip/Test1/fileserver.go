package main

import (
	"fmt"
	"net/http"
)

func main() {
	fmt.Println("Server Started")
	fs := http.FileServer(http.Dir("./static"))
	http.Handle("/static/", http.StripPrefix("/static", fs))
	http.ListenAndServe(":8000", nil)
}
