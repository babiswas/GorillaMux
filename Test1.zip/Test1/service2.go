package main

import (
	"fmt"
	"net/http"

	"github.com/gin-gonic/gin"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
)

type Book struct {
	ID     uint   `json:"id" gorm:"primary_key"`
	Title  string `json:"title"`
	Author string `json:"author"`
}

type CreateBookInput struct {
	Title  string `json:"title" binding:"required"`
	Author string `json:"author" binding:"required"`
}

func Get_db() (*gorm.DB, error) {
	dsn := "host=localhost user=postgres password=36network dbname=bookstore port=5433"
	db, err := gorm.Open(postgres.Open(dsn), &gorm.Config{})
	if err != nil {
		fmt.Println("Error Occured")
		return db, err
	}
	return db, nil
}

func Create_Table() {
	db, err := Get_db()
	if err != nil {
		fmt.Println("Error Occured")
		return
	}
	if !db.Migrator().HasTable("books") {
		db.AutoMigrate(&Book{})
	} else {
		fmt.Println("Table exists")
	}
}

func FindBooks(c *gin.Context) {
	db, err := Get_db()
	if err != nil {
		fmt.Println("Error Occured", err.Error())
	}
	var books []Book
	db.Find(&books)
	c.JSON(http.StatusOK, gin.H{"data": books})
}

func CreateBook(c *gin.Context) {
	var input CreateBookInput
	db, err := Get_db()
	if err != nil {
		fmt.Println("Error occured")
		return
	}
	if err := c.ShouldBindJSON(&input); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	book := Book{Title: input.Title, Author: input.Author}
	db.Create(&book)
	c.JSON(http.StatusOK, gin.H{"data": book})
}

func FindBook(c *gin.Context) {
	var book Book
	db, err := Get_db()
	if err != nil {
		fmt.Println("Error occured", err.Error())
	}
	if err := db.Where("id=?", c.Param("id")).First(&book).Error; err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Record not found!"})
		return
	}
	c.JSON(http.StatusOK, gin.H{"data": book})
}

func main() {
	r := gin.Default()
	Create_Table()
	r.GET("/books", FindBooks)
	r.POST("/books", CreateBook)
	r.GET("/books/:id", FindBook)
	r.Run(":9000")
}
