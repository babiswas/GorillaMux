package Service

import (
	"fmt"
	"io"
	"net/http"
)

func Show_job(w http.ResponseWriter, r *http.Request) {
	if r.Method == http.MethodGet {
		fmt.Fprintf(w, "Obtained a job")
		io.WriteString(w, "Completed Job")
		fmt.Println(string(r.URL.Path[1:]))
		w.WriteHeader(http.StatusOK)
	} else {
		w.WriteHeader(http.StatusBadRequest)
	}
}

func Create_job(w http.ResponseWriter, r *http.Request) {
	if r.Method == http.MethodPost {
		fmt.Println("Post method executing")
		fmt.Println(string(r.URL.Path[1:]))
		io.WriteString(w, "Post method executed")
	} else if r.Method == http.MethodGet {
		fmt.Println("Get method executed")
		fmt.Println(string(r.URL.Path[1:]))
		io.WriteString(w, "Get method executed")
	}
}
