package main

import (
	"Test1/Service"
	"fmt"
	"log"
	"net/http"
	"os"
	"path/filepath"
)

func main() {
	const Tmpdir = "./static"
	http.HandleFunc("/", Service.Show_job)
	http.HandleFunc("/test", Service.Create_job)
	http.HandleFunc("/static/", func(w http.ResponseWriter, r *http.Request) {
		wd, err := os.Getwd()
		if err != nil {
			fmt.Println("Error occured")
		}
		http.ServeFile(w, r, filepath.Join(wd, "/static/example1.html"))
	})
	log.Fatal(http.ListenAndServe(":8000", nil))
}
